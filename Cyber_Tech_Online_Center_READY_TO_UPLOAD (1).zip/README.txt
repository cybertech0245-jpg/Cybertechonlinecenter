CYBER TECH ONLINE CENTER - WEBSITE
===================================

Files:
- index.html : complete responsive website

To publish:
1. Upload index.html to your hosting public_html/www folder.
2. Point cybertechonlinecenter.in DNS to the hosting account.
3. Enable SSL/HTTPS.

The website is mobile-friendly and includes:
- Cyber Tech Online Center branding
- Online Services / Bank Mitra
- Xerox, Printing, Lamination, Spiral Binding
- Bhu-Bharathi
- AEPS
- Aadhaar, PAN, Voter ID
- MeeSeva / CSC
- Education, bills/recharge, typing/scanning, farmer services
- Phone and WhatsApp buttons
- Shop address
